def count_in_list(lst, string):
#  return sum(1 for elem in lst if elem == string)
 return lst.count(string)