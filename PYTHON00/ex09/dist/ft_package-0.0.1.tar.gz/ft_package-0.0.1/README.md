# ft_package

A sample test package for learning how to create and distribute Python packages.  
This project is part of a 42 exercise and demonstrates how to package simple functions with `pyproject.toml`.

---

## 🚀 Installation

Build the package first (this creates the `dist/` folder):

```bash
python -m build
