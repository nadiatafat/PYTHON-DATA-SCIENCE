# ft_package/__init__.py
from .countlist import count_in_list
